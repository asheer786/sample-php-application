PHP+MySQL Elastic Beanstalk sample
==========================

This sample demonstrates how to setup continuous integration and deployment for a PHP+MySQL project deployed using Amazon Elastic Beanstalk.

For more detailed documentation, please see Shippable's continuous deployment section.  http://docs.shippable.com/en/latest/config.html#continuous-deployment
